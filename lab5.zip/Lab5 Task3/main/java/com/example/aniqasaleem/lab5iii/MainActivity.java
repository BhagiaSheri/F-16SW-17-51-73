package com.example.aniqasaleem.lab5iii;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager mSensorManager;
    private Sensor mGyroscope;
    ImageView im;
    int A[];
   // int A[]= {R.drawable.ic_launcher_background,R.drawable.ic_launcher_foreground};
    //t A[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mGyroscope = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        im= findViewById(R.id.imageView2);
        A= new int[]{R.drawable.pica, R.drawable.picb, R.drawable.picc, R.drawable.picd, R.drawable.pice};
        im.setImageResource(A[0]);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mSensorManager.registerListener(this,mGyroscope,SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onStop() {
        super.onStop();
    mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Toast.makeText(getApplicationContext(), "Value"+event.values[2], Toast.LENGTH_SHORT).show();
      int count = 2;
      if(count<0 || count>A.length){
          count=2;
      }
        if(event.values[2] > 0.1 ){

            count--;
            //im.setImageResource(A[count]);
           // Toast.makeText(getApplicationContext(),"left",Toast.LENGTH_SHORT).show();
        }
        if(event.values[2]< -0.1 ) {

                count++;
              // im.setImageResource(A[count]);
             //   Toast.makeText(getApplicationContext(), "right", Toast.LENGTH_SHORT).show();
            }

            if(count>0 && count<A.length){
                im.setImageResource(A[count]);
            }


        }




    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
