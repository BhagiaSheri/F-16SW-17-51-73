package com.example.aniqasaleem.lab5ii;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager mSensorManager;
    Sensor mProximity;
    int SENSOR_SENSITIVITY = 4;
    ImageView iv;
    float x ;
    float y ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       iv = findViewById(R.id.imageView);
       mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
       mProximity = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);

       x=iv.getScaleX();
       y=iv.getScaleY();

    }
    @Override
    protected void onResume() {

        super.onResume();
        mSensorManager.registerListener(this, mProximity, SensorManager.SENSOR_DELAY_NORMAL );
    }
    @Override
    protected void onPause(){
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY){
            if (event.values[0] >= -SENSOR_SENSITIVITY && event.values[0] <= SENSOR_SENSITIVITY) {
                   iv.setScaleX(x*3);

                  iv.setScaleY(y*3);
                Toast.makeText(getApplicationContext(), "near", Toast.LENGTH_SHORT).show();
            }
        else{
                iv.setScaleX(x);
                iv.setScaleY(y);
                Toast.makeText(getApplicationContext(), "far", Toast.LENGTH_SHORT).show();
            }
    }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
