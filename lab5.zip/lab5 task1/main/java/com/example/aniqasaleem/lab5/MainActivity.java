package com.example.aniqasaleem.lab5;

import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener , ScaleGestureDetector.OnScaleGestureListener{
GestureDetectorCompat gestureDetectorCompat;
ScaleGestureDetector scaleGestureDetector;
float scaleFactor = 1.0f;
 ImageView I;
     int A []={R.drawable.pica,R.drawable.picb,R.drawable.picc,R.drawable.picd,R.drawable.pice,R.drawable.picf};
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gestureDetectorCompat = new GestureDetectorCompat(this,this);
        scaleGestureDetector= new ScaleGestureDetector(this,this);
        I= findViewById(R.id.imageView);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
       scaleGestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);

    }


    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }


    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        int count = 2;
   if (e1.getX() > e2.getX() ){
       if(count<7) {
           count++;
           I.setImageResource(A[count]);
           Toast.makeText(getApplicationContext(), "Left Swipe", Toast.LENGTH_SHORT).show();

       }

   } if (e2.getX() > e1.getX()){
        if (count>0){    count--;
            I.setImageResource(A[count]);
            Toast.makeText(getApplicationContext(), "Right Swipe", Toast.LENGTH_SHORT).show();
        }}
        else Toast.makeText(getApplicationContext(),"No more swipe",Toast.LENGTH_SHORT).show();
        return true;
    }

    @Override
    public boolean onScale(ScaleGestureDetector detector) {
        scaleFactor *= scaleGestureDetector.getScaleFactor();
        scaleFactor = Math.max(0.1f,Math.min(scaleFactor,10.0f));
        I.setScaleX(scaleFactor);
        I.setScaleY(scaleFactor);
        return true;


    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector detector) {
        return false;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector detector) {

    }
}
